// app/pages/pages.routes.ts
import { Routes } from '@angular/router';
import { Crud } from './pages/crud';

export default [
  { path: 'crud', component: Crud }
] as Routes;