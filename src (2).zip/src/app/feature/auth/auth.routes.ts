import { Routes } from '@angular/router';
import { Access } from './pages/access-denied/access.component.';
import { Login } from './pages/login/login';
import { Error } from './pages/error/error';
import { Registrar } from './pages/registrar/Registrar';
import { RecoverPasswordComponent } from './pages/recovery-password/RecoveryPassword';
import { VerifyCodeComponent } from './pages/verify-code/veryCode';
import { Identificacion } from './pages/identificacion/Identificacion';



export default [
    { path: 'access', component: Access },
    { path: 'error', component: Error },
    { path: 'login', component: Login },
    { path: 'Registrar', component: Registrar },
    { path: 'Recovery-password', component: RecoverPasswordComponent },
    { path: 'veryCode', component: VerifyCodeComponent },
    { path: 'Identificacion', component: Identificacion },
] as Routes;
